<?php
define('HOST', 'localhost');
define('DATABASE', 'web_assignment');
define('USERNAME', 'root');
define('PASSWORD', '');
define('PRIVATE_KEY', 'sjdgfsdj(*&*&6234jhsdgfjhsdsdfk&*^UUUdd');