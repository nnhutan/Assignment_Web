import React from "react";

function Order({ clickHandler, currUser }) {
  return <div className="container-fluid p-0"></div>;
}

export default Order;
