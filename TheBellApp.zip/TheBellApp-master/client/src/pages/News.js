import NewsPage from "../components/NewsPage";
function News() {
  return (
    <div className="news-page">
      <NewsPage />
    </div>
  );
}

export default News;
